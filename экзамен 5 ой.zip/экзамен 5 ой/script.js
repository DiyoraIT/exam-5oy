let h1 = document.querySelector(".h1")
let inp1 = document.querySelector(".first-inp")
let inp2 = document.querySelector(".second-inp")
let button = document.querySelector(".btn")









